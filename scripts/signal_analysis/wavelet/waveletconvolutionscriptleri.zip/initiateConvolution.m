function [erspData, itpcData, nobasedata]= initiateConvolution(data,waveparams)
%%% data = times X trials x channels
%%% waveparams = structure variable with fields containing wavelet parameters
%%%
%%%
countTrials=size(data,2);
countChannels=size(data,3);
countTimes=size(data,1);

freq_range=waveparams.freq_range;
freqsteps=waveparams.freqsteps;
freqcount=((freq_range(2)-freq_range(1))/freqsteps)+1;
itpcData=nan(freqcount,size(data,1),size(data,3));
erspData=nan(freqcount,size(data,1),size(data,3));

for chani = 1:countChannels
fprintf('\nProcessing channel: %f', chani);    
tmpdata=concatenateData(data(:,:,chani),[]);

tmpdata=waveletconv_mert(tmpdata,waveparams.srate,waveparams.freq_range,waveparams.freqsteps,waveparams.cycles);

tmpdata=deconcatenateData(tmpdata,[freqcount,countTimes,countTrials]);

[tmpitpc, tmpavg]=computePowerAndPhase(tmpdata,3);
% size(tmpavg)
basedata=waveletBaseline(tmpavg,waveparams.baselineperiod);

itpcData(:,:,chani)=tmpitpc;

erspData(:,:,chani)=basedata;

nobasedata(:,:,chani)=tmpavg;
end


